﻿ 
app.factory('platformWebApp.pushNotifications', ['$resource', function ($resource) {

    return $resource('api/platform/pushnotifications/:id', { id: '@Id' }, {
        markAllAsRead: { method: 'POST', url: 'api/platform/pushnotifications/markAllAsRead' },
        query: { method: 'POST', url: 'api/platform/pushnotifications' }
	});
}]);


 
app.factory('platformWebApp.pushNotificationService', ['$rootScope', 'platformWebApp.signalRHubProxy', '$timeout', '$interval', 'platformWebApp.pushNotifications', 'platformWebApp.signalRServerName',
    function ($rootScope, signalRHubProxy, $timeout, $interval,  notifications, signalRServerName) {

    	var clientPushHubProxy = signalRHubProxy(signalRServerName, 'clientPushHub', { logging: true });
    	clientPushHubProxy.on('notification', function (data) {
    		debugger;
    	});

    	function animateNotify() {
    		var notifyMenu = mainMenuService.findByPath('pushNotifications');
    		notifyMenu.incremented = true;

    		$timeout(function () {
    			notifyMenu.incremented = false;
    		}, 1500);
    	}

    	function markAllAsRead() {
    		var notifyMenu = mainMenuService.findByPath('pushNotifications');
    		if (angular.isDefined(notifyMenu.intervalPromise)) {
    			$interval.cancel(notifyMenu.intervalPromise);
    		}

    		notifications.markAllAsRead(null, function (data, status, headers, config) {
    			notifyMenu.incremented = false;
    			notifyMenu.newCount = 0;
    		}, function (error) {
    			//bladeNavigationService.setError('Error ' + error.status, blade);
    		});
    	}

    	var retVal = {
    		run: function () {
    			if (!this.running) {
    				var notifyMenu = mainMenuService.findByPath('pushNotifications');
    				if (!angular.isDefined(notifyMenu)) {
    					notifyMenu = {
    						path: 'pushNotifications',
    						icon: 'fa fa-bell-o',
    						title: 'platform.menu.notifications',
    						priority: 2,
    						permission: '',
    						headerTemplate: '$(Platform)/Scripts/app/pushNotifications/menuHeader.tpl.html',
    						listTemplate: '$(Platform)/Scripts/app/pushNotifications/menuList.tpl.html',
    						template: '$(Platform)/Scripts/app/pushNotifications/menu.tpl.html',
    						action: function () { markAllAsRead(); if (this.children.length == 0) { this.showHistory(); } },
    						showHistory: function () { $state.go('pushNotificationsHistory'); },
    						clearRecent: function () { notifyMenu.children.splice(0, notifyMenu.children.length); },
    						children: [],
    						newCount: 0
    					};
    					mainMenuService.addMenuItem(notifyMenu);
    				}
    				this.running = true;
    			};
    		},
    		running: false
    	};
    	return retVal;

    }]);
