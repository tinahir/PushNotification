﻿'use strict';

var app = angular.module('signalRIntegrationApp', []);

// Specify SignalR server URL here for supporting CORS
app.value('signalRServer', '');

app.factory('platformWebApp.signalRServerName', ['$location', function ($location) {
	var retVal = $location.url() ? $location.absUrl().slice(0, -$location.url().length - 1) : $location.absUrl();
	return retVal;
}])
//app.value('signalRServer', 'http://myserver.com:7778/');