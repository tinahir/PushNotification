﻿'use strict';

function ServerTimeController($scope, signalRHubProxy) {
	var clientPushHubProxy = signalRHubProxy(signalRHubProxy.defaultServer, 'clientPushHub', { logging: true });
	$scope.notifications = [];

	clientPushHubProxy.on('notification', function (data) {
		debugger;
    	$scope.notifications.push(data);
    	console.log(data);
    });
};

//function PerformanceDataController($scope, signalRHubProxy) {
//    var performanceDataHub = signalRHubProxy(signalRHubProxy.defaultServer, 'performanceDataHub');
    
//    performanceDataHub.on('newCpuDataValue', function (data) {
//        $scope.cpuData = data;
//    });
//};