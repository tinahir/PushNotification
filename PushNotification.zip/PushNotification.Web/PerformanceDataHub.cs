﻿using System.Diagnostics;
using System.Threading;
using Microsoft.AspNet.SignalR;
using System;

namespace Henriquatre.Integration.SignalR
{
    public class PerformanceDataHub : Hub
    {
    }
}