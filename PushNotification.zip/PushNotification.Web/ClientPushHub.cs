﻿using Microsoft.AspNet.SignalR;
using System;

namespace Henriquatre.Integration.SignalR
{
    public class ClientPushHub : Hub
    {
    }
}