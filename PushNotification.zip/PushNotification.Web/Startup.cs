﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartup(typeof(Henriquatre.Integration.SignalR.Startup))]

namespace Henriquatre.Integration.SignalR
{
	public class Startup
	{
		public void Configuration(IAppBuilder app)
		{
			app.MapSignalR();
		}
	}
}
