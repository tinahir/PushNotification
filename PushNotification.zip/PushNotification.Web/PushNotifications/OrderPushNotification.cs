﻿using Newtonsoft.Json;
using PushNotification.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PushNotification.Web
{
	public class OrderPushNotification : PushNotificationItem
	{
		public OrderPushNotification(string creator)
			: base(creator)
		{

		}

		[JsonProperty("started")]
		public DateTime? Started { get; set; }

		[JsonProperty("finished")]
		public DateTime? Finished { get; set; }
		 
	}
}