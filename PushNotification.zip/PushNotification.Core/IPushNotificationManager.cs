﻿namespace PushNotification.Core
{
    public interface IPushNotificationManager
    {
        void Upsert(PushNotificationItem notification);
        PushNotificationSearchResult SearchNotifies(string userId, PushNotificationSearchCriteria criteria);

    }
}
