﻿using System.Collections.Generic;

namespace PushNotification.Core
{
    public class PushNotificationSearchResult
    {
        public PushNotificationSearchResult()
        {
            NotifyEvents = new List<PushNotificationItem>();
        }
        public int TotalCount { get; set; }
        public int NewCount { get; set; }
        public List<PushNotificationItem> NotifyEvents { get; set; }
    }
}
